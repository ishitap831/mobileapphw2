package com.example.mycontactlist;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;

public class ContactSettingsActivity extends AppCompatActivity {


    RadioGroup colorGroup;
    RadioButton colorButton;
    SharedPreferences prefs;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_settings);
        initListButton();
        initMapButton();
        initSettingsButton();
        colorGroup = (RadioGroup)findViewById(R.id.colorsGroup);

        prefs = getSharedPreferences("myPrefs",Context.MODE_PRIVATE);

        RadioButton color1 = (RadioButton)findViewById(R.id.color1);
        RadioButton color12 = (RadioButton)findViewById(R.id.color2);

        color1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectid = colorGroup.getCheckedRadioButtonId();
                colorButton = (RadioButton) findViewById(selectid);

                String color = colorButton.getText().toString();
                SharedPreferences.Editor  editor = prefs.edit();
                editor.putString("color_key",color);
                editor.commit();
                ScrollView scrollView = (ScrollView)findViewById(R.id.colorscrollview);
                if(color.equals("Olive")){
                    scrollView.setBackgroundResource(R.color.pink);
                }else if(color.equals("Purple")){
                    scrollView.setBackgroundResource(R.color.periwinkle);
                }
            }
        });

        color12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectid = colorGroup.getCheckedRadioButtonId();
                colorButton = (RadioButton) findViewById(selectid);

                String color = colorButton.getText().toString();
                SharedPreferences.Editor  editor = prefs.edit();
                editor.putString("color_key",color);
                editor.commit();
                ScrollView scrollView = (ScrollView)findViewById(R.id.colorscrollview);
                if(color.equals("Olive")){
                    scrollView.setBackgroundResource(R.color.pink);
                }else if(color.equals("Purple")){
                    scrollView.setBackgroundResource(R.color.periwinkle);
                }
            }
        });


        if(prefs.getString("color_key",null).equals("Olive")){
            ScrollView scrollView = (ScrollView)findViewById(R.id.colorscrollview);
            scrollView.setBackgroundResource(R.color.pink);
        }else if(prefs.getString("color_key",null).equals("Purple")){
            ScrollView scrollView = (ScrollView)findViewById(R.id.colorscrollview);
            scrollView.setBackgroundResource(R.color.periwinkle);
        }



    }




    private void initListButton() {
        ImageButton ibList = (ImageButton) findViewById(R.id.imageButtonList);
        ibList.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ContactSettingsActivity.this, ContactListActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }

    private void initMapButton() {
        ImageButton ibList = (ImageButton) findViewById(R.id.imageButtonMap);
        ibList.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ContactSettingsActivity.this, ContactMapActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }

    private void initSettingsButton() {
        ImageButton ibList = (ImageButton) findViewById(R.id.imageButtonSettings);
        ibList.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ContactSettingsActivity.this, ContactSettingsActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }

}
