package com.example.mycontactlist;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;

public class ContactSettingsActivity extends AppCompatActivity {


    RadioGroup colorGroup;
    RadioButton colorButton;
    SharedPreferences prefs;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_settings);
        initListButton();
        initMapButton();
        initSettingsButton();
        colorGroup = (RadioGroup)findViewById(R.id.colorsGroup);

        prefs = getSharedPreferences("myPrefs",Context.MODE_PRIVATE);

        RadioButton color1 = (RadioButton)findViewById(R.id.color1);
        RadioButton color12 = (RadioButton)findViewById(R.id.color2);

        color1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectid = colorGroup.getCheckedRadioButtonId();
                colorButton = (RadioButton) findViewById(selectid);

                String color = colorButton.getText().toString();
                SharedPreferences.Editor  editor = prefs.edit();
                editor.putString("color_key",color);
                editor.commit();
                ScrollView scrollView = (ScrollView)findViewById(R.id.colorscrollview);
                if(color.equals("pink")){
                    scrollView.setBackgroundResource(R.color.pink);
                }
                else if(color.equals("purple")){
                    scrollView.setBackgroundResource(R.color.purple);
                }
                else if(color.equals("red")){
                    scrollView.setBackgroundResource(R.color.red);
                }
                else if(color.equals("maroon")){
                    scrollView.setBackgroundResource(R.color.MAROON);
                }
                else if(color.equals("green")){
                    scrollView.setBackgroundResource(R.color.GREEN);
                }
                else if(color.equals("fuchsia")){
                    scrollView.setBackgroundResource(R.color.FUCHSIA);
                }
                else if(color.equals("salmon")){
                    scrollView.setBackgroundResource(R.color.salmon);
                }
                else if(color.equals("teal")){
                    scrollView.setBackgroundResource(R.color.TEAL);
                }
                else if(color.equals("silver")){
                    scrollView.setBackgroundResource(R.color.SILVER);
                }
                else if(color.equals("gray")){
                    scrollView.setBackgroundResource(R.color.GRAY);
                }
                else if(color.equals("olive")){
                    scrollView.setBackgroundResource(R.color.OLIVE);
                }else if(color.equals("blue")){
                    scrollView.setBackgroundResource(R.color.blue);
                }
            }
        });

        color12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectid = colorGroup.getCheckedRadioButtonId();
                colorButton = (RadioButton) findViewById(selectid);

                String color = colorButton.getText().toString();
                SharedPreferences.Editor  editor = prefs.edit();
                editor.putString("color_key",color);
                editor.commit();
                ScrollView scrollView = (ScrollView)findViewById(R.id.colorscrollview);
                if(color.equals("pink")){
                    scrollView.setBackgroundResource(R.color.pink);
                }
                else if(color.equals("purple")){
                    scrollView.setBackgroundResource(R.color.purple);
                }
                else if(color.equals("red")){
                    scrollView.setBackgroundResource(R.color.red);
                }
                else if(color.equals("maroon")){
                    scrollView.setBackgroundResource(R.color.MAROON);
                }
                else if(color.equals("green")){
                    scrollView.setBackgroundResource(R.color.GREEN);
                }
                else if(color.equals("fuchsia")){
                    scrollView.setBackgroundResource(R.color.FUCHSIA);
                }
                else if(color.equals("salmon")){
                    scrollView.setBackgroundResource(R.color.salmon);
                }
                else if(color.equals("teal")){
                    scrollView.setBackgroundResource(R.color.TEAL);
                }
                else if(color.equals("silver")){
                    scrollView.setBackgroundResource(R.color.SILVER);
                }
                else if(color.equals("gray")){
                    scrollView.setBackgroundResource(R.color.GRAY);
                }
                else if(color.equals("olive")){
                    scrollView.setBackgroundResource(R.color.OLIVE);
                }else if(color.equals("blue")){
                    scrollView.setBackgroundResource(R.color.blue);
                }
            }
        });

    }




    private void initListButton() {
        ImageButton ibList = (ImageButton) findViewById(R.id.imageButtonList);
        ibList.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ContactSettingsActivity.this, ContactListActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }

    private void initMapButton() {
        ImageButton ibList = (ImageButton) findViewById(R.id.imageButtonMap);
        ibList.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ContactSettingsActivity.this, ContactMapActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }

    private void initSettingsButton() {
        ImageButton ibList = (ImageButton) findViewById(R.id.imageButtonSettings);
        ibList.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ContactSettingsActivity.this, ContactSettingsActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }

}
