package com.example.mycontactlist;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ContactListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_list);
    }
}
